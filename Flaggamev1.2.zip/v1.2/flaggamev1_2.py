from tkinter import *
import random

window = Tk()
window.title('Country Flags Game')
window.geometry('300x328')

highscoresave = open('highscore.txt', 'r')
highscore = int(highscoresave.readline())
highscoresave.close

flagimg = PhotoImage(file='country-flags/np.png')
flaglabel = Label(window, image=flagimg)
flaglabel.grid(row=2, column=0, pady=10)

streak = 0
streaklabel = Label(text='')
streaklabel.grid(row=4, column=0)

listname = ['Andorra', 'United Arab Emirates', 'Afghanistan', 'Antigua and Barbuda', 'Albania', 'Armenia', 'Angola', 'Argentina', 'Austria', 'Australia', 'Azerbaijan', 'Bosnia and Herzegovina', 'Barbados', 'Bangladesh', 'Belgium', 'Burkina Faso', 'Bulgaria', 'Bahrain', 'Burundi', 'Benin', 'Brunei', 'Bolivia', 'Brazil', 'Bahamas', 'Bhutan', 'Botswana', 'Belarus', 'Belize', 'Canada', 'Democratic Republic of the Congo', 'Central African Republic', 'Republic of the Congo', 'Switzerland', 'Ivory Coast', 'Chile', 'Cameroon', 'China', 'Colombia', 'Costa Rica', 'Cuba', 'Cape Verde', 'Cyprus', 'Czechia', 'Germany', 'Djibouti', 'Denmark', 'Dominica', 'Dominican Republic', 'Algeria', 'Ecuador', 'Estonia', 'Egypt', 'Eritrea', 'Spain', 'Ethiopia', 'Finland', 'Fiji', 'Micronesia', 'France', 'Gabon', 'United Kingdom', 'Grenada', 'Georgia', 'French Guiana', 'Ghana', 'Gambia', 'Guinea', 'Equatorial Guinea', 'Greece', 'Guatemala', 'Guinea-Bissau', 'Guyana', 'Honduras', 'Croatia', 'Haiti', 'Hungary', 'Indonesia', 'Ireland', 'Israel', 'India', 'Iraq', 'Iran', 'Iceland', 'Italy', 'Jamaica', 'Jordan', 'Japan', 'Kenya', 'Kyrgyzstan', 'Cambodia', 'Comoros', 'Saint Kitts and Nevis', 'Kosovo', 'North Korea', 'South Korea', 'Kuwait', 'Kazakhstan', 'Laos', 'Lebanon', 'Saint Lucia', 'Liechtenstein', 'Sri Lanka', 'Liberia', 'Lesotho', 'Lithuania', 'Luxembourg', 'Latvia', 'Libya', 'Morocco', 'Monaco', 'Moldova', 'Montenegro', 'Madagascar', 'Macedonia', 'Mali', 'Myanmar', 'Mongolia', 'Mauritania', 'Malta', 'Mauritius', 'Maldives', 'Malawi', 'Mexico', 'Malaysia', 'Mozambique', 'Namibia', 'Niger', 'Nigeria', 'Nicaragua', 'Netherlands', 'Norway', 'Nepal', 'Nauru', 'New Zealand', 'Oman', 'Panama', 'Peru', 'Papua New Guinea', 'Phillipines', 'Pakistan', 'Poland', 'Portugal', 'Palau', 'Paraguay', 'Qatar', 'Romania', 'Serbia', 'Russia', 'Rwanda', 'Saudi Arabia', 'Solomon Islands', 'Seychelles', 'Sudan', 'Sweden', 'Singapore', 'Slovenia', 'Slovakia', 'Sierra Leone', 'San Marino', 'Senegal', 'Somalia', 'Suriname', 'South Sudan', 'Sao Tome and Principe', 'El Salvador', 'Syria', 'Swaziland', 'Chad', 'Togo', 'Thailand', 'Tajikistan', 'East Timor', 'Turkmenistan', 'Tunisia', 'Tonga', 'Turkey', 'Trinidad and Tobago', 'Tuvalu', 'Taiwan', 'Tanzania', 'Ukraine', 'Uganda', 'United States', 'Uruguay', 'Uzbekistan', 'Vatican City', 'Saint Vincent and the Grenadines', 'Venezuela', 'Vietnam', 'Vanuatu', 'Samoa', 'Yemen', 'South Africa', 'Zambia', 'Zimbabwe', 'Marshall Islands', 'Kiribati']
listflag = ['ad.png', 'ae.png', 'af.png', 'ag.png', 'al.png', 'am.png', 'ao.png', 'ar.png', 'at.png', 'au.png', 'az.png', 'ba.png', 'bb.png', 'bd.png', 'be.png', 'bf.png', 'bg.png', 'bh.png', 'bi.png', 'bj.png', 'bn.png', 'bo.png', 'br.png', 'bs.png', 'bt.png', 'bw.png', 'by.png', 'bz.png', 'ca.png', 'cd.png', 'cf.png', 'cg.png', 'ch.png', 'ci.png', 'cl.png', 'cm.png', 'cn.png', 'co.png', 'cr.png', 'cu.png', 'cv.png', 'cy.png', 'cz.png', 'de.png', 'dj.png', 'dk.png', 'dm.png', 'do.png', 'dz.png', 'ec.png', 'ee.png', 'eg.png', 'er.png', 'es.png', 'et.png', 'fi.png', 'fj.png', 'fm.png', 'fr.png', 'ga.png', 'gb.png', 'gd.png', 'ge.png', 'gf.png', 'gh.png', 'gm.png', 'gn.png', 'gq.png', 'gr.png', 'gt.png', 'gw.png', 'gy.png', 'hn.png', 'hr.png', 'ht.png', 'hu.png', 'id.png', 'ie.png', 'il.png', 'in.png', 'iq.png', 'ir.png', 'is.png', 'it.png', 'jm.png', 'jo.png', 'jp.png', 'ke.png', 'kg.png', 'kh.png', 'km.png', 'kn.png', 'kosovo.png', 'kp.png', 'kr.png', 'kw.png', 'kz.png', 'la.png', 'lb.png', 'lc.png', 'li.png', 'lk.png' , 'lr.png', 'ls.png', 'lt.png', 'lu.png', 'lv.png', 'ly.png', 'ma.png', 'id.png', 'md.png', 'me.png', 'mg.png', 'mk.png', 'ml.png', 'mm.png', 'mn.png', 'mr.png', 'mt.png', 'mu.png', 'mv.png', 'mw.png', 'mx.png', 'my.png', 'mz.png', 'na.png', 'ne.png', 'ng.png', 'ni.png', 'nl.png', 'no.png', 'np.png', 'nr.png', 'nz.png', 'om.png', 'pa.png', 'pe.png', 'pg.png', 'ph.png', 'pk.png', 'pl.png', 'pt.png', 'pw.png', 'py.png', 'qa.png', 'ro.png', 'rs.png', 'ru.png', 'rw.png', 'sa.png', 'sb.png', 'sc.png', 'sd.png', 'se.png', 'sg.png', 'si.png', 'sk.png', 'sl.png', 'sm.png', 'sn.png', 'so.png', 'sr.png', 'ss.png', 'st.png', 'sv.png', 'sy.png', 'sz.png', 'ro.png', 'tg.png', 'th.png', 'tj.png', 'tl.png', 'tm.png', 'tn.png', 'to.png', 'tr.png', 'tt.png', 'tv.png', 'tw.png', 'tz.png', 'ua.png', 'ug.png', 'us.png', 'uy.png', 'uz.png', 'va.png', 'vc.png', 've.png', 'vn.png', 'vu.png', 'ws.png', 'ye.png', 'za.png', 'zm.png', 'zw.png', 'mh.png', 'ki.png']
citylistname = ['Andorra la Vella', 'Abu Dhabi', 'Kabul', 'Saint John\'s', 'Tirana', 'Yerevan', 'Luanda', 'Buenos Aires', 'Vienna', 'Canberra', 'Baku', 'Sarajevo', 'Bridgetown', 'Dhaka', 'Brussles', 'Ouagadougou', 'Sofia', 'Manama', 'Bujumbura', 'Porto-Novo', 'Bandar Seri Begawan','La Paz''Sucre', 'Brasilia', 'Nassau', 'Thimphu', 'Gaborone', 'Minsk', 'Belmopan', 'Ottawa', 'Kinshasa', 'Bangui', 'Brazzaville', 'Bern', 'Yamoussoukro', 'Santiago', 'Yaounde', 'Beijing', 'Bogota', 'San Jose', 'Havana', 'Praia', 'Nicosia', 'Prague', 'Berlin', 'Djibouti', 'Copenhagen', 'Roseau', 'Santo Domingo', 'Algiers', 'Quito', 'Tallin', 'Cairo', 'Asmara', 'Madrid', 'Addis Ababa', 'Helsinki', 'Suva', 'Palikir', 'Paris', 'Libreville', 'London', 'Saint George\'s', 'Tbilisi', 'Cayenne', 'Accra', 'Banjul', 'Conakry', 'Malabo', 'Athens', 'Guatemala', 'Bissau', 'Georgetown', 'Tegucigalpa', 'Zagreb', 'Port-au-Prince', 'Budapset', 'Jakarta', 'Dublin', 'Jerusalem', 'New Delhi', 'Baghdad', 'Tehran', 'Reykjavik', 'Rome', 'Kingston', 'Amman', 'Tokyo', 'Nairobi', 'Bishkek', 'Phnom Penh', 'Moroni', 'Basseterre', 'Pristina', 'Pyongyang', 'Seoul', 'Kuwait', 'Astana', 'Vientiane', 'Beirut', 'Castries', 'Vaduz', 'Colombo''Sri Jayawardenepura Kotte', 'Monrovia', 'Maseru', 'Vilnius', 'Luxembourg', 'Riga', 'Tripoli', 'Rabat', 'Monaco', 'Chisinau', 'Podgorica', 'Antananarivo', 'Skopje', 'Bamako', 'Naypyidaw', 'Ulaanbaatar', 'Nouakchott', 'Valletta', 'Port Louis', 'Male', 'Lilongwe', 'Mexico', 'Kuala Lumpur', 'Maputo', 'Windhoek', 'Niamey', 'Abuja', 'Managua', 'Amsterdam', 'Oslo', 'Kathmandu', 'Yaren District', 'Wellington', 'Muscat', 'Panama', 'Lima', 'Port Moresby', 'Manila', 'Islamabad', 'Warsaw', 'Lisbon', 'Ngerulmud', 'Asuncion', 'Doha', 'Bucharest', 'Belgrade', 'Moscow', 'Kigali', 'Riyadh', 'Honiara', 'Victoria', 'Khartoum', 'Stockholm', 'Singapore', 'Ljubljana', 'Bratislava', 'Freetown', 'San Marino', 'Dakar', 'Mogadishu', 'Paramaribo', 'Juba', 'Sao Tome', 'San Salvador', 'Damascus', 'Lobamba''Mbabane', 'N\'Djamena', 'Lome', 'Bangkok', 'Dushanbe', 'Dili', 'Ashgabat', 'Tunis', 'Nuku\'alofa', 'Ankara', 'Port of Spain', 'Funafuti', 'Taipei', 'Dodoma', 'Kiev''Kyiv', 'Kampala', 'Washington DC', 'Montevideo', 'Tashkent', 'Vatican', 'Kingstown', 'Caracas', 'Hanoi', 'Port Vila', 'Apia', 'Sana\'a', 'Bloemfontein''Capetown''Pretoria', 'Lusaka', 'Harare', 'Majuro', 'Tarawa']

def checkanswer(event):
    global streak, streaklabel, highscore, cityanswer, cityguess, guesslist, userinput, guessbox
	
    userinput = str(guessbox.get())
    userinput = userinput.lower()
    userinput = userinput.replace(' ','')
	
    guesslist = list(userinput.split(',', 1))
    guess = guesslist[0]
	
    cityguess = str(guesslist[1:])
	
    cityguess = cityguess.replace('[','')
    cityguess = cityguess.replace(']','')
    cityguess = cityguess.replace(' ','')
    cityguess = cityguess.replace(',','')
    cityguess = cityguess.replace('\'','')
    cityguess = cityguess.replace('City','')

    streak = streak + 1
    
    if guess.lower() == answer.lower():
        correct()
        
    elif guess.lower() == 'Chad'.lower():
        if randflag == 145:
            correct()
            
    elif guess.lower() == 'Romania'.lower():
        if randflag == 167:
            correct()
            
    elif guess.lower() == 'Indonesia'.lower():
        if randflag == 109:
            correct()
            
    elif guess.lower() == 'Monaco'.lower():
        if randflag == 76:
            correct()
            
    else:
        label.config(text='Incorrect! The answer was\n'+listname[randflag]+'\nCaptial city bonuses must be in alpabetical order.')
        displayupdate()
        streak = 0
		
    if streak >= 3:
        streaklabel.config(text=str(streak)+' in a row!')
    else:
        streaklabel.config(text='')
		
    if streak > highscore:
        highscore = streak
        displayupdate()
        highscoresave = open('highscore.txt', 'w')
        highscoresave.write(str(highscore))
        highscoresave.close
        
    guessbox.delete(0, 'end')

def citycorrect():
    global cityguess, cityanswer, streak
    if cityguess == cityanswer:
        label.config(text='City and country correct!\n\nCaptial city bonuses must be in alpabetical order.')
        streak = streak + 1
    elif cityguess.lower() == 'ndjamena':
        if randflag == 145:
            correct()
    elif cityguess.lower() == 'bucharest':
        if randflag == 167:
            correct()
    elif cityguess.lower() == 'jakarta':
        if randflag == 109:
            correct()
    elif cityguess.lower() == 'monaco':
        if randflag == 76:
            correct()
    else:
	    label.config(text='Country correct!\n\nCaptial city bonuses must be in alpabetical order.')
def correct():
    global cityguess, cityanswer, streak
    citycorrect()
    displayupdate()


def highscorereset():
    global highscorelabel, highscore, streak
	
    highscoresave = open('highscore.txt', 'w')
    highscoresave.write('0')
    highscoresave.close
    
    highscore = 0
    streak = 0

    streaklabel.config(text=str(streak)+' in a row!')
    highscorelabel.config(text='Highscore: '+str(highscore))

highscorelabel = Button(text='Highscore: '+ str(highscore), command=highscorereset)

def displayupdate():
    global displayflag, flagimg, flaglabel, answer, randflag, highscore, highscorelabel, cityanswer
	
    randflag = random.randint(0,196)

    displayflag = listflag[randflag]
	
    flagimg = PhotoImage(file='country-flags/'+ displayflag)
    flaglabel = Label(window, image=flagimg)
    flaglabel.grid(row=2, column=0, pady=10)
	
    fullanswer = str(listname[randflag])
    answer = fullanswer.replace(' ','')
	
    cityfullanswer = str(citylistname[randflag])
    cityanswer = cityfullanswer
    cityanswer = cityanswer.replace(' ','')
    cityanswer = cityanswer.lower()

    highscorelabel.config(text='Highscore: '+str(highscore))
    highscorelabel.grid(row=5, column=0)
	

	
displayupdate()

label = Label(text="What country's flag is this?\n Bonus: Add the city for an extra point,\nseperate it from the country with a comma.")
label.grid(row=0, column=0)

guessbox = Entry(window)
guessbox.grid(row=1, column=0)

window.bind('<Return>', checkanswer) 

footer = Label(text="'The' is ommitted if it is the beginning of a\ncountries name. All names are in English.\nClick the Highscore button to reset it and the score to 0.\nCreated by Rocco Perciavalle. Updated October 22, 2017")
footer.grid(row=6, column=0)

mainloop()
